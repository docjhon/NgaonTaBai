﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using NgaonTaBai.Models;

public class RestaurantsController : Controller
{
    private static readonly List<Restaurant> Restaurants = new List<Restaurant>
    {
        new Restaurant { Id = 1, Name = "Buko Seaside Bar and Restaurant", Cuisine = "Filipino, Thai, Asian", Location = "Kontiki Datag Maribago, Lapu-lapu 6015 Philippines", Description = "Buko seaside bar and restaurant is the perfect place to taste authentic Asian fusion cuisine and offer the best local and imported ingredients. Sit back and relax while enjoying some of the best views on the island. It is the perfect spot for your intimate meals or special occasions at Buko, our staff prioritize quick service and with the famously warm Filipino smile.", ImageUrl = "/images/buko.jpg", Rating = 4.8 },
        new Restaurant { Id = 2, Name = "Café Talk Library", Cuisine = "N/A", Location = "731 N Escario St, Cebu City, Cebu", Description = "Whether you’re looking for a cafe to enjoy coffee, read, study, or work, Cafe Talk Library is your best bet. With its 28 private nooks, you can easily concentrate on whatever tasks you have on your to-do list. The bright and colorful aesthetic of this Instagrammable cafe in Cebu will also surely rev up your focus together with their popular Java Chip and Caramel Macchiato drinks.", ImageUrl = "/images/CT.jpg", Rating = 4.1 },
        new Restaurant { Id = 3, Name = "Chikaan IL Corso", Cuisine = "Filipino", Location = "Ground Level, IL Corso Filinvest Lifemalls Cebu City", Description = "For over 30 years, Chikaan sa Cebu has continued its long-standing tradition of serving authentic Filipino dishes to Cebuanos. They serve a variety of traditional dishes from all over the country on their menu.", ImageUrl = "/images/chikaan.jpg", Rating = 4.2 }
    };

    public IActionResult Index()
    {
        return View(Restaurants);
    }

    public IActionResult Details(int id)
    {
        var restaurant = Restaurants.FirstOrDefault(r => r.Id == id);
        if (restaurant == null)
        {
            return NotFound();
        }
        return View(restaurant);
    }
}
