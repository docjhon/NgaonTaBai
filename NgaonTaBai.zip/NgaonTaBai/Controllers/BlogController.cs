﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

public class BlogController : Controller
{
    List<BlogPost> blogPosts = new List<BlogPost>
    {
        new BlogPost
        {
            Id = 1,
            Title = "Top 5 Restaurants to Visit",
            Author = "John Doe",
            PublishDate = DateTime.Now.AddDays(-10),
            Summary = "Explore the top 5 must-visit restaurants in the city.",
            ImageUrl = "/images/exp.jpg",
            Content = "Discover the best dining experiences in the city. From fine dining to casual eateries, here are the top 5 restaurants you must visit: " +
                      "1. Buko Seaside Bar and Restaurant, " +
                      "2. DIP Nikkei, Scape Skydeck, " +
                      "3. Scape Skydeck, " +
                      "4. Gold Mango Grill & Restaurant, " +
                      "5. CookPub - Modern Korean Bistro. " +
                      "Enjoy the exquisite cuisines, beautiful ambiance, and exceptional service that these places offer. Make your dining experience unforgettable with our top picks."        },
        new BlogPost
        {
            Id = 2,
            Title = "Chef's Secrets Revealed",
            Author = "Jane Smith",
            PublishDate = DateTime.Now.AddDays(-7),
            Summary = "Discover the culinary secrets from the top chefs.",
            ImageUrl = "/images/disc.jpg",
            Content = "Ever wondered what goes on behind the scenes in the kitchen of a top chef? We reveal the secrets and techniques that chefs use to create their signature dishes. From selecting the freshest ingredients to mastering the art of plating, get an insider's look into the culinary world."
        },
        new BlogPost
        {
            Id = 3,
            Title = "Healthy Eating Tips",
            Author = "Alice Johnson",
            PublishDate = DateTime.Now.AddDays(-3),
            Summary = "Maintain a healthy diet with these essential tips.",
            ImageUrl = "/images/mtn.jpg",
            Content = "Maintaining a healthy diet doesn't have to be difficult. With these essential tips, you can enjoy delicious and nutritious meals every day. Learn how to balance your diet, incorporate more fruits and vegetables, and make healthier choices without sacrificing taste."
        }
    };

    public IActionResult Index()
    {
        return View(blogPosts);
    }

    public IActionResult Details(int id)
    {
        var blogPost = blogPosts.FirstOrDefault(post => post.Id == id);
        if (blogPost == null)
        {
            return NotFound();
        }

        return View(blogPost);
    }
}
