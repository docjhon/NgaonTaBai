﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

public class NewDishesController : Controller
{
        private static readonly List<NewDish> newDishes = new List<NewDish>
        {
            new NewDish { Id = 1, Name = "Striploin Steak", Description = "PH Beef High Prime Grade", RestaurantName = "Buko Seaside Bar and Restaurant", ImageUrl = "/images/steak.jpg" },
            new NewDish { Id = 2, Name = "Coffee Latte", Description = "At Café Talk Library, we take pride in crafting the perfect coffee experience for our customers. Step into our cozy ambiance and treat yourself to the timeless delight of a classic coffee latte.", RestaurantName = "Café Talk Library", ImageUrl = "/images/coffee.jpg" },
            new NewDish { Id = 3, Name = "Crispy Pata", Description = "At Chikaan IL Corso, we invite you to indulge in the culinary masterpiece known as Crispy Pata. A Filipino favorite, Crispy Pata combines tender pork hock with a delectably crispy exterior, creating a dish that is both succulent and satisfying.", RestaurantName = "Chikaan IL Corso", ImageUrl = "/images/CP.jpg" }
        };
    public IActionResult Index()
    {
        return View(newDishes);
    }

    public IActionResult Details(int id)
    {
        var NewDish = newDishes.FirstOrDefault(r => r.Id == id);
        if (NewDish == null)
        {
            return NotFound();
        }
        return View(NewDish);
    }
}

